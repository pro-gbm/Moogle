package com.progbm.Moogle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoogleApplicationTests {

	@Test
	void contextLoads() {
	}

}
