package com.progbm.Moogle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoogleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoogleApplication.class, args);
	}

}
